/*
	  Ackerman's function, A(m, n) is defined:
     A(0 , n) = n + 1 for n  >= 0 
     A(m , 0) = A(m � 1 , 1) for m > 0
     A(m , n) = A(m � 1 , A(m , n - 1)) for n >= 0
*/

public class Recursion
{
	public static long ackermann(long m, long n)
	{
						

	}// end ackermann
	
}// end class