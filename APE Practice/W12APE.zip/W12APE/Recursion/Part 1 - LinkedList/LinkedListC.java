public class LinkedListC extends LinkedList
{
   // If the list is empty, print the message "The list is empty"
	// Check the indexes to ensure
	// -fromIndex is not less than 0
	// -toIndex is not greater than size
	// -fromIndex is less than toIndex
	// throw an IndexOutOfBoundsException if one of the indexes are incorrect
	// otherwise print the nodes fromIndex to toIndex in reverse order
  	public void subListReverse(int fromIndex, int toIndex)
	{
				
	}// end subListReverse
	  	
}// end class
