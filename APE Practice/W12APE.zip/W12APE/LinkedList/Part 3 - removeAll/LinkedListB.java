public class LinkedListB extends LinkedList
{
 	public boolean removeAll(Integer [] array)
	{	
			
	}// end removeAll
	
	   	
}// end class