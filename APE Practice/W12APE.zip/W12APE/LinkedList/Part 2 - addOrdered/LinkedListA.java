public class LinkedListA extends LinkedList
{
     // NOTE:  this is NOT one of the methods in the Java API LinkedList
      // Precondition:  The list on entry is properly sorted.
		// Postcondition: List has new data and is in ascending order
      public void addOrdered(Comparable dataToAdd)
		{
					
		}// end addOrdered		
			
}// end class
