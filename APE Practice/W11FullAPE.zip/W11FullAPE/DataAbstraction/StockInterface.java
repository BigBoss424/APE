public interface StockInterface
{
	public abstract double calcDividend();

}// end class