public class LongHair extends Cat
{  LongHair(String name, int wt)
   {  super(name,wt);  }
}