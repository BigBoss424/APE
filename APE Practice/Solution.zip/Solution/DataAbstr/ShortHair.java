public class ShortHair extends Cat
{  ShortHair(String name, int wt)
   {  super(name,wt);  }
}