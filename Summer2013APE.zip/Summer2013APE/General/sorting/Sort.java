/*

	Write the sort method for the sort class.
	It takes an array of Comparable and sorts it.
	Be sure and handle edge cases as pointed out by
	the Tester.
	No API calls to sort are allowed.
	
	10 points
*/

public class Sort
{
	
	


}//end class Sort