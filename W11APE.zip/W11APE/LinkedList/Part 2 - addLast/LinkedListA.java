public class LinkedListA extends LinkedList
{
   	
}// end class
