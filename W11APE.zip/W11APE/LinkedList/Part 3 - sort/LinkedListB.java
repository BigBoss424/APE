public class LinkedListB extends LinkedListA
{
   
}// end class