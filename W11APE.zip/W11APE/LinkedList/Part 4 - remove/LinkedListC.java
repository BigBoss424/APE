public class LinkedListC extends LinkedListB
{
   
	
	
	
		
}// end class