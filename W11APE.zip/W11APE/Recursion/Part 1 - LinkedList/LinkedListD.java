public class LinkedListD extends LinkedListC
{
   // If the list is empty, print the message "The list is empty."
   // Otherwise list all the data fields, one to a line --- IN REVERSE.





}// end class
